# Band 5 Kontrol

Mi Smart Band 5 (XMSH10HM) için BLE kontrol uygulaması + video canlı duvar kağıdı.

- Auth key ile bileklik doğrulama, pil, adım, canlı nabız, titret, test mesajı
- Videoyu telefon duvar kağıdı yap (sessiz döngü, doldur/uzat)
- Test edilmedi: günlük bölümü hataları gösterir
