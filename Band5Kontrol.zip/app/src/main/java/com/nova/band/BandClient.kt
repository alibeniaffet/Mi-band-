package com.nova.band

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Mi Smart Band 5 (XMSH10HM) BLE istemcisi.
 * Protokol, Gadgetbridge / miband4 topluluk çalışmalarındaki Huami kimlik doğrulamasına dayanır.
 * Henüz gerçek cihazla doğrulanmadı: sonuçlar log satırlarında gösterilir.
 */
@SuppressLint("MissingPermission")
class BandClient(private val ctx: Context, private val l: Listener) {

    interface Listener {
        fun onState(text: String, connected: Boolean, ready: Boolean)
        fun onBattery(percent: Int)
        fun onSteps(steps: Int, meters: Int, kcal: Int)
        fun onHeartRate(bpm: Int)
        fun onLog(s: String)
    }

    companion object {
        private fun std(s: String) = UUID.fromString("0000$s-0000-1000-8000-00805f9b34fb")
        private fun huami(s: String) = UUID.fromString("0000$s-0000-3512-2118-0009af100700")

        val SVC_FEE0: UUID = std("fee0")
        val SVC_FEE1: UUID = std("fee1")
        val CH_AUTH: UUID = huami("0009")
        val CH_BATTERY: UUID = huami("0006")
        val CH_STEPS: UUID = huami("0007")
        val SVC_HR: UUID = std("180d")
        val CH_HR_MEASURE: UUID = std("2a37")
        val CH_HR_CTRL: UUID = std("2a39")
        val SVC_ALERT: UUID = std("1802")
        val CH_ALERT_LEVEL: UUID = std("2a06")
        val SVC_NEW_ALERT: UUID = std("1811")
        val CH_NEW_ALERT: UUID = std("2a46")
        val CCCD: UUID = std("2902")
    }

    private val main = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var gatt: BluetoothGatt? = null
    private var scanCb: ScanCallback? = null
    private var key = ByteArray(16)
    private var authFlags = 0x00
    private var triedAlt = false
    private var authed = false

    private var chAuth: BluetoothGattCharacteristic? = null
    private var chBattery: BluetoothGattCharacteristic? = null
    private var chSteps: BluetoothGattCharacteristic? = null
    private var chHrMeasure: BluetoothGattCharacteristic? = null
    private var chHrCtrl: BluetoothGattCharacteristic? = null
    private var chAlertLevel: BluetoothGattCharacteristic? = null
    private var chNewAlert: BluetoothGattCharacteristic? = null

    private val queue = ArrayDeque<() -> Boolean>()
    private var busy = false
    private var hrOn = false

    fun isBluetoothOn(): Boolean = adapter?.isEnabled == true
    fun isReady(): Boolean = authed

    private fun ui(f: () -> Unit) {
        main.post(f)
    }

    // ---------------------------------------------------------------- tarama

    fun startScan(onFound: (BluetoothDevice, Int, String) -> Unit): Boolean {
        val sc = adapter?.bluetoothLeScanner ?: return false
        stopScan()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                val n = result.scanRecord?.deviceName ?: (try { d.name } catch (e: Exception) { null }) ?: ""
                val low = n.lowercase()
                if (low.contains("band") || low.contains("mi ") || low.contains("xiaomi") || low.contains("amazfit")) {
                    ui { onFound(d, result.rssi, n) }
                }
            }
        }
        scanCb = cb
        return try {
            sc.startScan(cb)
            main.postDelayed({ stopScan() }, 20000L)
            true
        } catch (e: Exception) {
            scanCb = null
            false
        }
    }

    fun stopScan() {
        val cb = scanCb ?: return
        scanCb = null
        try {
            adapter?.bluetoothLeScanner?.stopScan(cb)
        } catch (e: Exception) {
        }
    }

    fun deviceFor(address: String): BluetoothDevice? {
        return try {
            adapter?.getRemoteDevice(address)
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- bağlantı

    fun connect(device: BluetoothDevice, authKey: ByteArray) {
        disconnect()
        stopScan()
        key = authKey
        authFlags = 0x00
        triedAlt = false
        authed = false
        l.onState("Bağlanıyor…", false, false)
        try {
            gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            l.onState("Bağlanılamadı: ${e.message}", false, false)
        }
    }

    fun disconnect() {
        main.removeCallbacksAndMessages(null)
        queue.clear()
        busy = false
        hrOn = false
        authed = false
        val g = gatt
        gatt = null
        if (g != null) {
            try {
                g.disconnect()
            } catch (e: Exception) {
            }
            try {
                g.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun fail(msg: String) {
        l.onLog("✗ $msg")
        l.onState(msg, true, false)
    }

    // ---------------------------------------------------------------- işlem kuyruğu

    private fun enqueue(op: () -> Boolean) {
        queue.addLast(op)
        pump()
    }

    private fun pump() {
        if (busy) return
        val op = queue.removeFirstOrNull() ?: return
        busy = true
        val started = try {
            op()
        } catch (e: Exception) {
            false
        }
        if (!started) {
            busy = false
            main.post { pump() }
        }
    }

    private fun done() {
        busy = false
        main.post { pump() }
    }

    private fun write(c: BluetoothGattCharacteristic?, v: ByteArray) {
        enqueue {
            val g = gatt
            if (c == null || g == null) {
                false
            } else {
                c.writeType = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) {
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                } else {
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                }
                c.value = v
                g.writeCharacteristic(c)
            }
        }
    }

    private fun read(c: BluetoothGattCharacteristic?) {
        enqueue {
            val g = gatt
            if (c == null || g == null) false else g.readCharacteristic(c)
        }
    }

    private fun enableNotify(c: BluetoothGattCharacteristic?) {
        enqueue {
            val g = gatt
            val d = c?.getDescriptor(CCCD)
            if (c == null || g == null || d == null) {
                false
            } else {
                g.setCharacteristicNotification(c, true)
                d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                g.writeDescriptor(d)
            }
        }
    }

    // ---------------------------------------------------------------- GATT geri çağrıları

    private val callback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                ui { l.onState("Bağlandı, servisler aranıyor…", true, false) }
                main.postDelayed({
                    try {
                        g.discoverServices()
                    } catch (e: Exception) {
                    }
                }, 600L)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                authed = false
                ui { l.onState("Bağlantı kapandı (kod $status)", false, false) }
                try {
                    g.close()
                } catch (e: Exception) {
                }
                if (gatt === g) gatt = null
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val fee0 = g.getService(SVC_FEE0)
            val fee1 = g.getService(SVC_FEE1)
            chAuth = fee1?.getCharacteristic(CH_AUTH) ?: fee0?.getCharacteristic(CH_AUTH)
            chBattery = fee0?.getCharacteristic(CH_BATTERY)
            chSteps = fee0?.getCharacteristic(CH_STEPS)
            chHrMeasure = g.getService(SVC_HR)?.getCharacteristic(CH_HR_MEASURE)
            chHrCtrl = g.getService(SVC_HR)?.getCharacteristic(CH_HR_CTRL)
            chAlertLevel = g.getService(SVC_ALERT)?.getCharacteristic(CH_ALERT_LEVEL)
            chNewAlert = g.getService(SVC_NEW_ALERT)?.getCharacteristic(CH_NEW_ALERT)
            if (chAuth == null) {
                ui { fail("Kimlik doğrulama servisi bulunamadı. Bu bir Mi Band 5 mi?") }
                return
            }
            ui { l.onState("Kimlik doğrulanıyor…", true, false) }
            enableNotify(chAuth)
            requestRandom()
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            when (c.uuid) {
                CH_AUTH -> handleAuth(v)
                CH_HR_MEASURE -> {
                    if (v.size >= 2) {
                        val bpm = v[1].toInt() and 0xFF
                        if (bpm in 30..230) ui { l.onHeartRate(bpm) }
                    }
                }
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            val v = c.value
            if (status == BluetoothGatt.GATT_SUCCESS && v != null) {
                when (c.uuid) {
                    CH_BATTERY -> if (v.size >= 2) {
                        val p = v[1].toInt() and 0xFF
                        ui { l.onBattery(p) }
                    }
                    CH_STEPS -> if (v.size >= 13) {
                        val steps = u16(v, 1)
                        val meters = i32(v, 5)
                        val kcal = i32(v, 9)
                        ui { l.onSteps(steps, meters, kcal) }
                    } else if (v.size >= 3) {
                        val steps = u16(v, 1)
                        ui { l.onSteps(steps, 0, 0) }
                    }
                }
            } else {
                ui { l.onLog("Okuma hatası (kod $status)") }
            }
            done()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) ui { l.onLog("Yazma hatası (kod $status)") }
            done()
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            done()
        }
    }

    private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun i32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or
            ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or
            ((b[o + 3].toInt() and 0xFF) shl 24)

    // ---------------------------------------------------------------- kimlik doğrulama

    private fun requestRandom() {
        ui { l.onLog("→ rastgele sayı isteniyor (authFlags=0x${Integer.toHexString(authFlags)})") }
        write(chAuth, byteArrayOf(0x82.toByte(), authFlags.toByte(), 0x02, 0x01, 0x00))
    }

    private fun aes(data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/ECB/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
        return c.doFinal(data)
    }

    private fun handleAuth(v: ByteArray) {
        if (v.size < 3 || v[0] != 0x10.toByte()) return
        val raw = v[1].toInt() and 0xFF
        val crypt = raw and 0x80
        val cmd = raw and 0x7F
        val status = v[2].toInt() and 0xFF
        ui { l.onLog("← auth cmd=0x${Integer.toHexString(cmd)} durum=0x${Integer.toHexString(status)}") }
        when (cmd) {
            0x02 -> {
                if (status == 0x01 && v.size >= 19) {
                    val random = v.copyOfRange(3, 19)
                    val enc = try {
                        aes(random)
                    } catch (e: Exception) {
                        ui { fail("Şifreleme hatası: ${e.message}") }
                        return
                    }
                    val head = byteArrayOf((0x03 or crypt).toByte(), authFlags.toByte())
                    write(chAuth, head + enc)
                } else {
                    ui { fail("Rastgele sayı alınamadı (kod $status)") }
                }
            }
            0x03 -> {
                if (status == 0x01) {
                    authed = true
                    ui {
                        l.onLog("✓ kimlik doğrulandı")
                        l.onState("Bağlı ve doğrulandı ✓", true, true)
                    }
                    readBattery()
                    readSteps()
                } else if (!triedAlt) {
                    triedAlt = true
                    authFlags = if (authFlags == 0x00) 0x08 else 0x00
                    requestRandom()
                } else {
                    ui { fail("Anahtar reddedildi (kod $status). Auth key'i kontrol et.") }
                }
            }
        }
    }

    // ---------------------------------------------------------------- komutlar

    fun readBattery() {
        if (authed) read(chBattery)
    }

    fun readSteps() {
        if (authed) read(chSteps)
    }

    private val hrPing = object : Runnable {
        override fun run() {
            if (hrOn) {
                write(chHrCtrl, byteArrayOf(0x16))
                main.postDelayed(this, 12000L)
            }
        }
    }

    fun startHeart() {
        if (!authed || hrOn) return
        hrOn = true
        enableNotify(chHrMeasure)
        write(chHrCtrl, byteArrayOf(0x15, 0x02, 0x00))
        write(chHrCtrl, byteArrayOf(0x15, 0x01, 0x00))
        write(chHrCtrl, byteArrayOf(0x15, 0x01, 0x01))
        main.postDelayed(hrPing, 12000L)
    }

    fun stopHeart() {
        if (!hrOn) return
        hrOn = false
        main.removeCallbacks(hrPing)
        write(chHrCtrl, byteArrayOf(0x15, 0x01, 0x00))
    }

    fun isHeartOn(): Boolean = hrOn

    fun vibrate() {
        if (!authed) return
        write(chAlertLevel, byteArrayOf(0x02))
        main.postDelayed({ write(chAlertLevel, byteArrayOf(0x00)) }, 2500L)
    }

    fun sendMessage(text: String) {
        if (!authed) return
        val body = text.take(60).toByteArray(Charsets.UTF_8)
        write(chNewAlert, byteArrayOf(0x05, 0x01) + body)
    }
}
