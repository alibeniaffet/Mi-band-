package com.nova.band

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.view.Surface
import android.view.SurfaceHolder
import java.io.File

/** Seçilen videoyu ana ekran / kilit ekranında sessizce döngüyle oynatan canlı duvar kağıdı. */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {

        private var mp: MediaPlayer? = null
        private var surface: Surface? = null
        private val sp: SharedPreferences = getSharedPreferences("wall", Context.MODE_PRIVATE)

        private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                "version" -> startPlayer()
                "mute" -> applyVolume()
                "scale" -> applyScale()
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            sp.registerOnSharedPreferenceChangeListener(prefListener)
        }

        override fun onDestroy() {
            sp.unregisterOnSharedPreferenceChangeListener(prefListener)
            releasePlayer()
            super.onDestroy()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surface = holder.surface
            startPlayer()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            surface = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            val p = mp ?: return
            try {
                if (visible) p.start() else p.pause()
            } catch (e: Exception) {
            }
        }

        private fun startPlayer() {
            releasePlayer()
            val s = surface ?: return
            val f = File(filesDir, "wallpaper.mp4")
            if (!f.exists()) return
            try {
                val p = MediaPlayer()
                p.setSurface(s)
                p.setDataSource(f.absolutePath)
                p.isLooping = true
                p.setOnPreparedListener { pl ->
                    mp = pl
                    applyVolume()
                    applyScale()
                    if (isVisible) {
                        try {
                            pl.start()
                        } catch (e: Exception) {
                        }
                    }
                }
                p.setOnErrorListener { _, _, _ -> true }
                mp = p
                p.prepareAsync()
            } catch (e: Exception) {
                releasePlayer()
            }
        }

        private fun applyVolume() {
            val p = mp ?: return
            try {
                if (sp.getBoolean("mute", true)) p.setVolume(0f, 0f) else p.setVolume(1f, 1f)
            } catch (e: Exception) {
            }
        }

        private fun applyScale() {
            val p = mp ?: return
            try {
                p.setVideoScalingMode(
                    if (sp.getString("scale", "crop") == "stretch") {
                        MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT
                    } else {
                        MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    }
                )
            } catch (e: Exception) {
            }
        }

        private fun releasePlayer() {
            val p = mp
            mp = null
            if (p != null) {
                try {
                    p.stop()
                } catch (e: Exception) {
                }
                try {
                    p.release()
                } catch (e: Exception) {
                }
            }
        }
    }
}
