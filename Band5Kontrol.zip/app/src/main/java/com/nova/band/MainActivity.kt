package com.nova.band

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.bluetooth.BluetoothDevice
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

/** Nabız grafiği: son ölçümleri çizgi olarak gösterir. */
class HrChart(ctx: Context) : View(ctx) {
    var data: List<Int> = emptyList()
    var lineColor: Int = Color.RED
    var gridColor: Int = Color.GRAY
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = gridColor
        for (i in 0..3) {
            val y = h * i / 3f
            c.drawLine(0f, y, w, y, p)
        }
        if (data.size < 2) return
        val mn = (data.minOrNull() ?: 60).coerceAtMost(60) - 5
        val mx = (data.maxOrNull() ?: 100).coerceAtLeast(100) + 5
        val path = Path()
        for ((i, v) in data.withIndex()) {
            val x = w * i / (data.size - 1).toFloat()
            val y = h - h * (v - mn).toFloat() / (mx - mn).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        p.strokeWidth = 2.5f * d
        p.color = lineColor
        c.drawPath(path, p)
    }
}

class MainActivity : Activity(), BandClient.Listener {

    private val REQ_PERM = 77
    private val REQ_VIDEO = 78

    private lateinit var client: BandClient
    private lateinit var prefs: SharedPreferences
    private lateinit var wall: SharedPreferences
    private lateinit var content: LinearLayout
    private var scroll: ScrollView? = null
    private var tab = 0

    private var dark = false
    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private val accent = Color.parseColor("#FF6900")
    private val green = Color.parseColor("#2EB67D")
    private val red = Color.parseColor("#E5484D")

    // bileklik durumu
    private var stateText = "Bağlı değil"
    private var connected = false
    private var ready = false
    private var battery = -1
    private var steps = -1
    private var meters = 0
    private var kcal = 0
    private var bpm = 0
    private val hrSeries = ArrayList<Int>()
    private val logs = ArrayList<String>()
    private val devices = LinkedHashMap<String, Triple<BluetoothDevice, String, Int>>()
    private var scanning = false
    private var pendingAction: (() -> Unit)? = null

    private var hrTv: TextView? = null
    private var hrChart: HrChart? = null
    private var batTv: TextView? = null
    private var stepsTv: TextView? = null
    private var logTv: TextView? = null

    // duvar kağıdı durumu
    private var wallThumb: Bitmap? = null
    private var wallInfo = ""
    private var wallStatus = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("band", Context.MODE_PRIVATE)
        wall = getSharedPreferences("wall", Context.MODE_PRIVATE)
        client = BandClient(this, this)
        applyColors()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(cBg)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, LinearLayout.LayoutParams(MP, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        setContentView(root)
        loadWallInfo()
        showTab(0)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyColors()
        showTab(tab)
    }

    override fun onDestroy() {
        client.stopHeart()
        client.disconnect()
        super.onDestroy()
    }

    private fun applyColors() {
        val night = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        dark = night == Configuration.UI_MODE_NIGHT_YES
        cBg = Color.parseColor(if (dark) "#101012" else "#F4F5F7")
        cCard = Color.parseColor(if (dark) "#1C1D21" else "#FFFFFF")
        cText = Color.parseColor(if (dark) "#E8EAED" else "#202124")
        cSub = Color.parseColor(if (dark) "#9AA0A6" else "#5F6368")
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(r).toFloat()
        if (stroke != 0) d.setStroke(dp(2), stroke)
        return d
    }

    private fun text(s: String, size: Float = 15f, color: Int = cText, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 10): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MP, WC)
        l.topMargin = dp(top)
        return l
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(cCard, 16)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun button(label: String, color: Int, filled: Boolean, onClick: () -> Unit): TextView {
        val b = text(label, 15f, if (filled) Color.WHITE else color, true)
        b.gravity = Gravity.CENTER
        b.background = if (filled) rounded(color, 12) else rounded(Color.TRANSPARENT, 12, color)
        b.setPadding(dp(14), dp(12), dp(14), dp(12))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(s: String): TextView {
        val t = text(s, 13f, accent, true)
        t.setPadding(dp(4), dp(20), 0, dp(2))
        return t
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun parseKey(s: String?): ByteArray? {
        if (s == null) return null
        var k = s.trim().lowercase(Locale.US).replace(" ", "").replace(":", "")
        if (k.startsWith("0x")) k = k.substring(2)
        if (k.length != 32 || !k.all { it in '0'..'9' || it in 'a'..'f' }) return null
        val out = ByteArray(16)
        for (i in 0 until 16) out[i] = k.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return out
    }

    // ---------------------------------------------------------------- sekmeler

    private fun showTab(i: Int) {
        tab = i
        val oldY = scroll?.scrollY ?: 0
        hrTv = null
        hrChart = null
        batTv = null
        stepsTv = null
        logTv = null
        content.removeAllViews()
        val page = if (i == 0) bandPage() else wallPage()
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(page, ViewGroup.LayoutParams(MP, WC))
        content.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))
        scroll = sv
        sv.post { sv.scrollTo(0, oldY) }

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(cCard)
        fun navBtn(label: String, idx: Int) {
            val t = text(label, 14f, if (idx == i) accent else cSub, idx == i)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener {
                if (tab != idx) showTab(idx)
            }
            nav.addView(t, LinearLayout.LayoutParams(0, WC, 1f))
        }
        navBtn("⌚ Bileklik", 0)
        navBtn("🎞 Duvar kağıdı", 1)
        content.addView(nav, LinearLayout.LayoutParams(MP, WC))
    }

    // ---------------------------------------------------------------- BILEKLIK SAYFASI

    private fun bandPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(24))

        col.addView(text("⌚ Mi Smart Band 5", 26f, cText, true))
        col.addView(text("Model XMSH10HM · Bluetooth 5.0 LE", 13f, cSub))

        // Auth key
        col.addView(section("KİMLİK ANAHTARI (AUTH KEY)"))
        val kc = card()
        val saved = prefs.getString("auth_key", "") ?: ""
        val keyOk = parseKey(saved) != null
        kc.addView(
            text(
                if (keyOk) "✅ Anahtar kayıtlı (••••" + saved.takeLast(4) + ")" else "❌ Anahtar girilmedi",
                14f, cText, true
            )
        )
        val input = EditText(this)
        input.hint = "32 karakterlik anahtar (0x ile başlayabilir)"
        input.setHintTextColor(cSub)
        input.setTextColor(cText)
        input.setText(saved)
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        input.background = rounded(if (dark) Color.parseColor("#2A2B30") else Color.parseColor("#EEF0F3"), 12)
        input.setPadding(dp(14), dp(12), dp(14), dp(12))
        kc.addView(input, lp(8))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val save = button("Kaydet", accent, true) {
            val k = input.text.toString()
            if (parseKey(k) == null) {
                toast("Anahtar 32 hex karakter olmalı")
            } else {
                prefs.edit().putString("auth_key", k.trim()).apply()
                toast("Kaydedildi")
                showTab(0)
            }
        }
        val help = button("Nasıl alınır?", accent, false) { keyHelp() }
        val l1 = LinearLayout.LayoutParams(0, WC, 1f)
        val l2 = LinearLayout.LayoutParams(0, WC, 1f)
        l2.leftMargin = dp(8)
        row.addView(save, l1)
        row.addView(help, l2)
        kc.addView(row, lp(10))
        col.addView(kc, lp(8))

        // Bağlantı
        col.addView(section("BAĞLANTI"))
        val cc = card()
        cc.addView(text(stateText, 15f, cText, true))
        cc.addView(
            text(
                "Önce Zepp Life / Mi Fit uygulamasını kapat. Bileklik aynı anda tek telefona bağlanır.",
                12f, cSub
            )
        )
        if (!connected) {
            cc.addView(button(if (scanning) "⏳ Taranıyor…" else "🔍 Bilekliği tara", accent, true) { startScan() }, lp(10))
            val lastAddr = prefs.getString("last_addr", "") ?: ""
            if (lastAddr.isNotEmpty()) {
                val lastName = prefs.getString("last_name", "bileklik") ?: "bileklik"
                cc.addView(button("↻ Son cihaza bağlan: $lastName", accent, false) {
                    ensurePerms {
                        val dev = client.deviceFor(lastAddr)
                        if (dev != null) connectTo(dev, lastName) else toast("Cihaz bulunamadı")
                    }
                }, lp(8))
            }
            for ((addr, t) in devices) {
                val name = t.second
                cc.addView(button("$name  ·  $addr  (${t.third} dBm)", green, false) {
                    connectTo(t.first, name)
                }, lp(8))
            }
        } else {
            cc.addView(button("Bağlantıyı kes", red, false) {
                client.stopHeart()
                client.disconnect()
                connected = false
                ready = false
                stateText = "Bağlantı kesildi"
                showTab(0)
            }, lp(10))
        }
        col.addView(cc, lp(8))

        if (ready) col.addView(dashboard())

        // Günlük
        col.addView(section("GÜNLÜK"))
        val lc = card()
        val lt = text(if (logs.isEmpty()) "Henüz kayıt yok" else logs.takeLast(12).joinToString("\n"), 11f, cSub)
        lt.typeface = Typeface.MONOSPACE
        lc.addView(lt)
        logTv = lt
        col.addView(lc, lp(8))

        val note = card()
        note.addView(
            text(
                "⚠️ Bu sürüm gerçek bileklikle test edilmedi. Bağlantı veya ölçüm sorun çıkarırsa yukarıdaki günlüğü " +
                    "olduğu gibi gönder, düzeltelim. Bileklik video watch face'i desteklemez (126×294 ekran, statik yüzler); " +
                    "video duvar kağıdı telefon içindir.",
                12f, cSub
            )
        )
        col.addView(note, lp(14))
        return col
    }

    private fun dashboard(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        col.addView(section("BİLEKLİK VERİLERİ"))
        val dc = card()
        val bt = text(batteryText(), 16f, cText, true)
        batTv = bt
        dc.addView(bt)
        val st = text(stepsText(), 14f, cText)
        stepsTv = st
        dc.addView(st)
        dc.addView(button("Yenile", accent, false) {
            client.readBattery()
            client.readSteps()
        }, lp(8))
        col.addView(dc, lp(8))

        col.addView(section("NABIZ"))
        val hc = card()
        val ht = text(if (bpm > 0) "$bpm" else "--", 44f, red, true)
        ht.gravity = Gravity.CENTER
        hrTv = ht
        hc.addView(ht)
        hc.addView(text("atım/dk", 12f, cSub).also { it.gravity = Gravity.CENTER })
        val chart = HrChart(this)
        chart.data = ArrayList(hrSeries)
        chart.lineColor = red
        chart.gridColor = if (dark) Color.parseColor("#33FFFFFF") else Color.parseColor("#22000000")
        hrChart = chart
        hc.addView(chart, LinearLayout.LayoutParams(MP, dp(110)))
        hc.addView(
            button(if (client.isHeartOn()) "■ Ölçümü durdur" else "❤ Canlı ölçümü başlat", red, true) {
                if (client.isHeartOn()) client.stopHeart() else client.startHeart()
                showTab(0)
            }, lp(10)
        )
        hc.addView(text("İlk değer gelmesi yaklaşık 10-30 saniye sürebilir. Bilekliği bileğine tak.", 12f, cSub))
        col.addView(hc, lp(8))

        col.addView(section("KONTROL"))
        val kc = card()
        kc.addView(button("📳 Bilekliği titret (bul)", accent, true) { client.vibrate() })
        kc.addView(button("💬 Test mesajı gönder (deneysel)", accent, false) {
            client.sendMessage("Merhaba! Band 5 Kontrol")
        }, lp(8))
        col.addView(kc, lp(8))
        return col
    }

    private fun batteryText() = if (battery >= 0) "🔋 Pil: $battery%" else "🔋 Pil: —"

    private fun stepsText() =
        if (steps >= 0) "👟 $steps adım · ${"%.2f".format(Locale.US, meters / 1000.0)} km · $kcal kcal" else "👟 Adım: —"

    private fun keyHelp() {
        AlertDialog.Builder(this)
            .setTitle("Auth key nasıl alınır?")
            .setMessage(
                "Mi Band 5, kimlik anahtarını Xiaomi/Huami sunucusunda saklar. Üçüncü taraf uygulamaların bağlanması için " +
                    "bu 32 karakterlik anahtar gerekir:\n\n" +
                    "1) Telefona Zepp Life (eski adı Mi Fit) uygulamasını kur, hesabınla giriş yap ve bilekliği eşleştir.\n" +
                    "2) Bilgisayarda “huami-token” betiğini (Python) çalıştırıp e-posta + şifrenle giriş yap. " +
                    "Çıktıdaki auth_key değeri anahtarındır. Gadgetbridge wikisindeki “Huami Server Pairing” sayfasında yöntemler anlatılıyor.\n" +
                    "3) Anahtarı buraya yapıştır (0x ile başlaması sorun değil).\n" +
                    "4) Zepp Life uygulamasını tamamen kapat, sonra “Bilekliği tara”ya bas.\n\n" +
                    "Anahtar bilekliğinin şifresidir, kimseyle paylaşma."
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    // ---------------------------------------------------------------- izinler ve tarama

    private fun needPerms(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun ensurePerms(action: () -> Unit) {
        val missing = needPerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            requestPermissions(missing.toTypedArray(), REQ_PERM)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            val a = pendingAction
            pendingAction = null
            if (ok && a != null) a() else toast("Bluetooth izni gerekli")
        }
    }

    private fun startScan() {
        if (parseKey(prefs.getString("auth_key", "")) == null) {
            toast("Önce geçerli bir auth key kaydet")
            return
        }
        ensurePerms {
            if (!client.isBluetoothOn()) {
                toast("Bluetooth'u aç")
            } else {
                devices.clear()
                scanning = true
                val ok = client.startScan { dev, rssi, name ->
                    devices[dev.address] = Triple(dev, name.ifBlank { "Bileklik" }, rssi)
                    if (tab == 0) showTab(0)
                }
                if (!ok) {
                    scanning = false
                    toast("Tarama başlatılamadı")
                }
                showTab(0)
                content.postDelayed({
                    scanning = false
                    if (tab == 0 && !connected) showTab(0)
                }, 20000L)
            }
        }
    }

    private fun connectTo(dev: BluetoothDevice, name: String) {
        val key = parseKey(prefs.getString("auth_key", ""))
        if (key == null) {
            toast("Önce geçerli bir auth key kaydet")
            return
        }
        scanning = false
        prefs.edit().putString("last_addr", dev.address).putString("last_name", name).apply()
        client.connect(dev, key)
    }

    // ---------------------------------------------------------------- BandClient.Listener

    override fun onState(text: String, connected: Boolean, ready: Boolean) {
        stateText = text
        this.connected = connected
        this.ready = ready
        if (!ready) hrSeries.clear()
        if (tab == 0) showTab(0)
    }

    override fun onBattery(percent: Int) {
        battery = percent
        batTv?.text = batteryText()
    }

    override fun onSteps(steps: Int, meters: Int, kcal: Int) {
        this.steps = steps
        this.meters = meters
        this.kcal = kcal
        stepsTv?.text = stepsText()
    }

    override fun onHeartRate(bpm: Int) {
        this.bpm = bpm
        hrSeries.add(bpm)
        while (hrSeries.size > 60) hrSeries.removeAt(0)
        hrTv?.text = bpm.toString()
        val c = hrChart
        if (c != null) {
            c.data = ArrayList(hrSeries)
            c.invalidate()
        }
    }

    override fun onLog(s: String) {
        logs.add(s)
        while (logs.size > 40) logs.removeAt(0)
        logTv?.text = logs.takeLast(12).joinToString("\n")
    }

    // ---------------------------------------------------------------- DUVAR KAĞIDI SAYFASI

    private fun wallPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(24))

        col.addView(text("🎞 Video Duvar Kağıdı", 26f, cText, true))
        col.addView(text("Telefonunun ana ekranında ve kilit ekranında seçtiğin video döngüyle oynar.", 13f, cSub))

        val f = File(filesDir, "wallpaper.mp4")
        val has = f.exists()

        col.addView(section("VİDEO"))
        val vc = card()
        val thumb = wallThumb
        if (has && thumb != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(thumb)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.clipToOutline = true
            iv.background = rounded(Color.BLACK, 12)
            vc.addView(iv, LinearLayout.LayoutParams(MP, dp(220)))
        }
        vc.addView(
            text(
                if (wallStatus.isNotEmpty()) wallStatus else if (has) wallInfo else "Henüz video seçilmedi",
                13f, cSub
            ), lp(8)
        )
        vc.addView(button("📁 Video seç", accent, true) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            try {
                startActivityForResult(i, REQ_VIDEO)
            } catch (e: Exception) {
                toast("Dosya seçici açılamadı")
            }
        }, lp(10))
        if (has) {
            vc.addView(button("🖼 Duvar kağıdı olarak ayarla", green, true) { setWallpaper() }, lp(8))
            vc.addView(button("🗑 Videoyu kaldır", red, false) {
                f.delete()
                wallThumb = null
                wallInfo = ""
                wall.edit().putInt("version", wall.getInt("version", 0) + 1).apply()
                showTab(1)
            }, lp(8))
        }
        col.addView(vc, lp(8))

        col.addView(section("AYARLAR"))
        val sc = card()
        val sw = Switch(this)
        sw.isChecked = !wall.getBoolean("mute", true)
        sw.setOnCheckedChangeListener { _, on -> wall.edit().putBoolean("mute", !on).apply() }
        val sr = LinearLayout(this)
        sr.orientation = LinearLayout.HORIZONTAL
        sr.gravity = Gravity.CENTER_VERTICAL
        val sc2 = LinearLayout(this)
        sc2.orientation = LinearLayout.VERTICAL
        sc2.addView(text("Sesi aç", 16f))
        sc2.addView(text("Varsayılan: sessiz", 12f, cSub))
        sr.addView(sc2, LinearLayout.LayoutParams(0, WC, 1f))
        sr.addView(sw)
        sc.addView(sr)

        val scale = wall.getString("scale", "crop") ?: "crop"
        val br = LinearLayout(this)
        br.orientation = LinearLayout.VERTICAL
        br.setPadding(0, dp(12), 0, 0)
        br.addView(text("Ölçekleme", 16f))
        br.addView(text(if (scale == "stretch") "Ekrana uzat" else "Doldur (kenarlardan kırp)", 13f, cSub))
        br.setOnClickListener {
            val labels = arrayOf("Doldur (kenarlardan kırp)", "Ekrana uzat")
            AlertDialog.Builder(this)
                .setTitle("Ölçekleme")
                .setSingleChoiceItems(labels, if (scale == "stretch") 1 else 0) { d, w ->
                    wall.edit().putString("scale", if (w == 1) "stretch" else "crop").apply()
                    d.dismiss()
                    showTab(1)
                }
                .setNegativeButton("İptal", null)
                .show()
        }
        sc.addView(br)
        col.addView(sc, lp(8))

        val nc = card()
        nc.addView(
            text(
                "• Pil tasarrufu için video yalnızca ekran görünürken oynar.\n" +
                    "• Kısa ve düşük çözünürlüklü (ör. 1080p, 10-30 sn) videolar daha az pil harcar.\n" +
                    "• Bazı telefonlar kilit ekranında canlı duvar kağıdını göstermez; ana ekranda çalışır.\n" +
                    "• Mi Band 5 video watch face desteklemez: ekranı 126×294 ve yalnızca hazır statik yüzleri gösterir.",
                12f, cSub
            )
        )
        col.addView(nc, lp(14))
        return col
    }

    private fun setWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        i.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, VideoWallpaperService::class.java)
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                toast("Duvar kağıdı ayarı açılamadı")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VIDEO && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importVideo(uri)
        }
    }

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (e: Exception) {
        }
        return "video"
    }

    private fun importVideo(uri: Uri) {
        wallStatus = "Video kopyalanıyor, bekle…"
        showTab(1)
        Thread {
            var ok = false
            try {
                val tmp = File(filesDir, "wallpaper.tmp")
                val dst = File(filesDir, "wallpaper.mp4")
                val ins = contentResolver.openInputStream(uri)
                if (ins != null) {
                    ins.use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o) } }
                    if (dst.exists()) dst.delete()
                    ok = tmp.renameTo(dst)
                }
            } catch (e: Exception) {
                ok = false
            }
            val name = queryName(uri)
            val info = if (ok) readVideoInfo(name) else null
            runOnUiThread {
                wallStatus = ""
                if (ok && info != null) {
                    wallThumb = info.first
                    wallInfo = info.second
                    wall.edit().putInt("version", wall.getInt("version", 0) + 1).putString("name", name).apply()
                    toast("Video hazır")
                } else {
                    toast("Video alınamadı")
                }
                if (tab == 1) showTab(1)
            }
        }.start()
    }

    private fun readVideoInfo(name: String): Pair<Bitmap?, String>? {
        val f = File(filesDir, "wallpaper.mp4")
        if (!f.exists()) return null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
            val dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
            var bmp: Bitmap? = r.getFrameAtTime(0)
            if (bmp != null && bmp.width > 720) {
                val k = 720f / bmp.width
                bmp = Bitmap.createScaledBitmap(bmp, 720, (bmp.height * k).toInt(), true)
            }
            val mb = f.length() / (1024 * 1024)
            return Pair(bmp, "$name\n${w}×$h · $dur sn · $mb MB")
        } catch (e: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun loadWallInfo() {
        if (!File(filesDir, "wallpaper.mp4").exists()) return
        val name = wall.getString("name", "video") ?: "video"
        Thread {
            val info = readVideoInfo(name)
            runOnUiThread {
                if (info != null) {
                    wallThumb = info.first
                    wallInfo = info.second
                    if (tab == 1) showTab(1)
                }
            }
        }.start()
    }
}
